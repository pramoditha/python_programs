class Animal:
    name="Mammal"
class Pets(Animal):
    colour="white"
class Dog(Pets):
    def bark(self):
        print(self.name)
        print(self.colour)
        print("Bow Bow")
d=Dog()
d.bark()