import math
a=6
b=5
print("The sum of a and b is ",a+b)
print("The remainder is ",a%b)
# k=input("enter")
# print(k)
# print(type(k))
# k=int(k)
# print(k)
# print(type(k))
print(type(a>b))
p=float(input("Enter"))
print(p**0.5)
print(math.sqrt(4))