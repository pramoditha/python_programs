num=int(input("Enter a number"))
i=1
sum=0
while i<=num:
    sum=sum+i
    i=i+1
print("Sum of numbers is ",sum)

