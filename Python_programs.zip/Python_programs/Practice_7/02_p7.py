l1=["harry","sohan","sachin","rahul"]
for k in l1:
    if k.startswith('s'):
        print("Hello "+k)