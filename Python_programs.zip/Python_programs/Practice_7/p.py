fruits=['banana','apple','watermelon']
i=0
while i<len(fruits):
    print(fruits[i])
    i=i+1
for k in fruits:
    print(k)
   
       