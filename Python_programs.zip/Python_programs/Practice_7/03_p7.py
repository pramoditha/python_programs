a=int(input("Enter a number:"))
i=1
while i<=10:
    print(a,"X",i,"=",a*i)
    i=i+1