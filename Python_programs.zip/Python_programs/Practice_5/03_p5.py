se={18,18.1,"18"}
print(se)
s=set()
s.add(20)
s.add(20.0)
s.add("20")
print(s)