content=True
i=1
with open('D:\\Python_L\\Practice_9\\log.txt','r') as f:
    while content:
        content=f.readline()
        if 'python' in content.lower():
            print("Python present")
            print("Line ",i)
        i+=1

