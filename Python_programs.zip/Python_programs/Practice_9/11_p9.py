import os
with open('D:\\Python_L\\Practice_9\\copy.txt','r') as f:
    content=f.read()
with open('D:\\Python_L\\Practice_9\\rename.txt','w') as f:
    f.write(content)
os.remove('D:\\Python_L\\Practice_9\\copy.txt')