file1="D:\\Python_L\\Practice_9\\log.txt"
file2="D:\\Python_L\\Practice_9\\copy.txt"
with open(file1,'r') as f:
    content1=f.read()
with open(file2,'r') as f:
    content2=f.read()
if content1==content2:
    print("Identical")
else:
    print("Not Identical")