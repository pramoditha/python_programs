import random
n=random.randint(0,1000)
with open('D:\\Python_L\\Practice_9\\highscore.txt','r') as f:
    high=f.read()
if high=='':
     with open('D:\\Python_L\\Practice_9\\highscore.txt','w') as f:
        f.write(str(n)) 
else:
    if int(high)<n:
        with open('D:\\Python_L\\Practice_9\\highscore.txt','w') as f:
            f.write(str(n))
