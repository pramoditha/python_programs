with open('D:\\Python_L\\Practice_9\\log.txt','r') as f:
    content=f.read()
if 'python' in content.lower():
    print("python is present")
else:
    print("Nope")