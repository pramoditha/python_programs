with open('D:\\Python_L\\Practice_9\\donkey.txt','r') as f:
    content=f.read()
with open('D:\\Python_L\\Practice_9\\copy.txt','w') as f:
    f.write(content)