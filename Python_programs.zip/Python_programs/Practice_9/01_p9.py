f1=open('D:\\Python_L\\Practice_9\\poems.txt')
data=f1.read()
if 'twinkle' in data:
    print("Present")
else:
    print("Not present")
f1.close()