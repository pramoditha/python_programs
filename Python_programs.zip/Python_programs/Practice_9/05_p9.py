lst=['donkey','kutta','dog']
with open('D:\\Python_L\\Practice_9\\donkey.txt','r') as f:
    content=f.read()
for word in lst:
    content=content.replace(word,'#####')
with open('D:\\Python_L\\Practice_9\\donkey.txt','w') as f:
    f.write(content)