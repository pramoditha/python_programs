def pr(n):
    for i in range(1,n+1):
        print("*"*(n-i+1))
num=int(input("Enter number:"))
pr(num)