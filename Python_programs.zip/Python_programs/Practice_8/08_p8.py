def mul(n):
    for i in range(1,11):
        print(f"{n}X{i}={i*n}")
num=int(input("Enter number:"))
mul(num)