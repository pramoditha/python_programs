def remove_strip(string,word):
    nstr=string.replace(word,"")
    return nstr.strip()
str=("   Harry hello welcome      ")
n=remove_strip(str,"Harry")
print(n)