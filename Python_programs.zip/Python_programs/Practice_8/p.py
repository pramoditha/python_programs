def greet(str):
    print("Good day "+str)
greet("harry")