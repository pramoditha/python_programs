letter='''Name: <|NAME|>
hello welcome
Date: <|DATE|>'''
name=input("Enter name:")
date=input("Enter date:")
letter.replace("<|NAME|>",name)
letter.replace("<|DATE|>",date)
print(letter)
letter=letter.replace("<|NAME|>",name)
letter=letter.replace("<|DATE|>",date)
print(letter)