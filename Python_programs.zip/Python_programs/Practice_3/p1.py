a="hello"
print(a[0:6])