str="jg kjhku  kg r lil haRRy lhku kjh"
str1=str.lower();
if ("harry" in str1):
    print("present")
else:
    print("not present")