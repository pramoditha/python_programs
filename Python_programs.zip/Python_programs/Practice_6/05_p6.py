names=["harry","rohit","shubam","ankit"]
a=input()
if a in names:
    print("Present")
else:
    print("Not present")