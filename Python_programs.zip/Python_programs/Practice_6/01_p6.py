print("Enter 4 numbers")
a=int(input())
b=int(input())
c=int(input())
d=int(input())
print("Greatest:4")
if(a>b and a>c and a>d):
    print(a)
elif(b>a and b>c and b>d):
    print(a)
elif(c>b and c>a and c>d):
    print(a)
else:
    print(d)